<p align="center">
  <a href="http://watchx.io/"> 
    <img src="./Pictures/TapClock_for_watchX_logo.png" alt="watchX"> 
  </a>
</p>

![](https://img.shields.io/github/license/venice1200/TapClock.svg?style=flat)  

TapClock is a simple Arduino based sketch for the watchX Hardware from ArgeX.  
See the README's in the release folder for more details.

Other information channels are:
* Reddit https://www.reddit.com/r/watchX/
* WatchX Community https://community.watchx.io

Cheers
