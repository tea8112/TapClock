Older TapClock Releases  
  
See sketches for more information.

Best Regards :-)
