TapClock v0.8.5  
See https://github.com/venice1200/TapClock/blob/master/TapClock/TapClock_v0.8.5/TapClock_v0.8.5_ReadMe.txt  
Added: Battery checks, Battery Alarm and Icon for MPU
